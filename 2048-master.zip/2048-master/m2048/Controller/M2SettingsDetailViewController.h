//
//  M2SettingsDetailViewController.h
//  m2048
//
//  Created by Danqing on 3/24/14.
//  Copyright (c) 2014 Danqing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface M2SettingsDetailViewController : UITableViewController

@property (nonatomic, strong) NSArray *options;
@property (nonatomic, strong) NSString *footer;

@end
